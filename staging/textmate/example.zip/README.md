# Louk Grammar
Syntax highlighting for Louk

<img width="400" src="assets/preview.png" alt="Syntax highlighting example" />

## Installation
## About
This package/repository is purely a distribution mechanism for build outputs from the [louk-grammar](https://github.com/agorischek/louk-grammar) repository. Contributions and modifications should be made in that repository.

